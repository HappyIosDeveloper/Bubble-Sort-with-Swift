//
//  RowTableViewCell.swift
//  bubble sort
//
//  Created by Alfredo on 9/9/22.
//

import UIKit

class RowTableViewCell: UITableViewCell {

    @IBOutlet weak var collectionView: UICollectionView!
    
    static let identifier = #function
    var cellWidth: CGFloat = 1
    var array: [Int] = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        collectionView.register(UINib(nibName: RowCollectionViewCell.identifier, bundle: nil), forCellWithReuseIdentifier: RowCollectionViewCell.identifier)
        collectionView.delegate = self
        collectionView.dataSource = self
    }
        
    func setup(with array: [Int], cellWidth: CGFloat) {
        self.cellWidth = cellWidth
        self.array = array
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
}

// MARK: CollectionView Functions
extension RowTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return array.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: RowCollectionViewCell.identifier, for: indexPath) as! RowCollectionViewCell
        let number = array[indexPath.row]
        let height: CGFloat = (CGFloat(number) * 100) / cellHeight
        cell.setup(with: height - 20, number: number) // 20 is titleLabel height
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let largestNumber = CGFloat(array.sorted(by: {$0 > $1}).first!)
        let height: CGFloat = (CGFloat(largestNumber) * 100) / cellHeight
        return CGSize(width: cellWidth, height: height + 10)
    }
}
