//
//  RowCollectionViewCell.swift
//  bubble sort
//
//  Created by Alfredo on 9/9/22.
//

import UIKit

class RowCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    @IBOutlet weak var view: UIView!
    
    static let identifier = #function
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        view.backgroundColor = .blue
    }
    
    func setup(with height: CGFloat, number: Int) {
        heightConstraint.constant = height
        titleLabel.text = number.description
    }
}
