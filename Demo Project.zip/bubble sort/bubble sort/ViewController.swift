//
//  ViewController.swift
//  bubble sort
//
//  Created by Alfredo on 9/9/22.
//

import UIKit

let cellHeight = UIScreen.main.bounds.width / 4
let screenWidth = UIScreen.main.bounds.width

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var numbers:[[Int]] = [[48, 26, 32, 38, 50, 33, 19, 17, 25 , 22]]
    let animationTime: Double = 0.4
    let stepPauseTime: Double = 0.5
    var cursor: Int = 0 {
        didSet {
            print("cursor: \(cursor)")
            DispatchQueue.main.async { [self] in
                tableView.reloadData()
                tableView.beginUpdates()
                tableView.endUpdates()
                scrollToBottom()
            }
        }
    }
    var currentRow: Int = 0 {
        didSet {
            print("currentRow: \(currentRow)")
            DispatchQueue.main.async { [self] in
                tableView.reloadData()
                tableView.beginUpdates()
                tableView.endUpdates()
                scrollToBottom()
            }
        }
    }
    var row: [Int] {
        get {
            return numbers[numbers.count - 1]
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTableView()
        startTheShow()
    }
}

// MARK: - Setup Views
extension ViewController {
    
    func setupTableView() {
        tableView.register(UINib(nibName: RowTableViewCell.identifier, bundle: nil), forCellReuseIdentifier: RowTableViewCell.identifier)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView()
    }
    
    func startTheShow() {
        drawTheRow()
    }
    
    func scrollToBottom() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [self] in
            let point = CGPoint(x: 0, y: tableView.contentSize.height + tableView.contentInset.bottom - tableView.frame.height)
            if point.y >= 0 {
                tableView.setContentOffset(point, animated: !true)
            }
        }
    }
}

// MARK: - TableView Functions
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numbers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: RowTableViewCell.identifier) as! RowTableViewCell
        let array = numbers[indexPath.row]
        cell.setup(with: array, cellWidth: screenWidth / CGFloat(array.count))
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }
}

// MARK: - Actions
extension ViewController {
    
    func wait(comple: @escaping ()->()) {
        DispatchQueue.main.asyncAfter(deadline: .now() + stepPauseTime) {
            comple()
        }
    }
    
    func drawTheRow() {
        if (cursor < numbers.first!.count-1) && (currentRow < numbers.count) && (cursor < numbers.first!.count - currentRow) {
            sortCurrentRow()
            cursor += 1
            if cursor < row.count-1 {
                preMoveAnimation()
            }
            wait { [self] in
                swapViews()
            }
        } else {
            print("*** finished sorting one row")
            cursor = 0
            if currentRow < numbers.first!.count {
                currentRow += 1
                wait { [self] in
                    swapViews()
                }
            } else {
                print("*** finished sorting!")
            }
        }
    }
    
    func swapViews() {
        if cursor < row.count-1 {
            if row[cursor] > row[cursor + 1] {
                UIView.animate(withDuration: animationTime / 2) { [self] in
                    moveAnimation()
                }
            } else {
                shrinkAnimation()
            }
        }
        wait { [self] in
            drawTheRow()
        }
    }
    
    func preMoveAnimation() {
        if let cell = tableView.cellForRow(at: IndexPath(row: numbers.count-1, section: 0)) as? RowTableViewCell {
            if let row1 = cell.collectionView.cellForItem(at: IndexPath(row: cursor, section: 0)) {
                if let row2 = cell.collectionView.cellForItem(at: IndexPath(row: cursor+1, section: 0)) {
                    let row1Frame = row1.frame
                    row1.frame = row2.frame
                    row2.frame = row1Frame
                    cell.layoutIfNeeded()
                }
            }
        }
    }
    
    func moveAnimation() {
        if let cell = tableView.cellForRow(at: IndexPath(row: numbers.count-1, section: 0)) as? RowTableViewCell {
            if let row1 = cell.collectionView.cellForItem(at: IndexPath(row: cursor, section: 0)) {
                if let row2 = cell.collectionView.cellForItem(at: IndexPath(row: cursor+1, section: 0)) {
                    let row1Frame = row1.frame
                    row1.frame = row2.frame
                    row2.frame = row1Frame
                    cell.layoutIfNeeded()
                }
            }
        }
    }
    
    func shrinkAnimation() {
        if let cell = tableView.cellForRow(at: IndexPath(row: numbers.count-1, section: 0)) as? RowTableViewCell {
            if let row = cell.collectionView.cellForItem(at: IndexPath(row: cursor, section: 0)) {
                UIView.animate(withDuration: animationTime / 2) {
                    row.transform = CGAffineTransform(scaleX: 0.7, y: 0.7)
                    row.layoutIfNeeded()
                } completion: { _ in
                    row.transform = CGAffineTransform(scaleX: 1, y: 1)
                    row.layoutIfNeeded()
                }
            }
        }
    }
}

// MARK: - Logics
extension ViewController {
    
    func sortCurrentRow() {
        if cursor == numbers.first!.count-1 { // last column
            return
        } else {
            if row[cursor] > row[cursor + 1] {
                var number = row
                number[cursor] = row[cursor + 1]
                number[cursor + 1] = row[cursor]
                numbers.append(number)
            }
        }
    }
}
